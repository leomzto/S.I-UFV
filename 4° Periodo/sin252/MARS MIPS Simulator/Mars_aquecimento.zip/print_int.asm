# print_int.asm
# ==================================================
.data
    my_int: .word 42

.text
    li $v0, 1
    la $t0, my_int
    lw $a0, 0($t0)
    
    syscall
    
    li $v0, 10
    syscall    

