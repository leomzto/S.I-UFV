# print_char
# ==================================================
.data # Area de dados na memoria
    my_char:  .byte 'S' # Variavel do tipo byte na memoria principal
	
.text  # Area de instrucoes na memoria
    li $v0, 4 # Codigo para imprimir char ou string 
    la $a0, my_char # Carrega o endereco da variavel (ponteiro) em $a0 
    syscall # Executa a chamada de sistema indicado pelo valor em $v0
    
    li $v0, 10 # Encerrar o programa
    syscall
	
