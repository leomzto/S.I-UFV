# hello_world.asm
# ==================================================
.data
    # Area de dados na memoria
    my_str: .asciiz "Hello, world!" # Variavel do tipo ascii na memoria principal
	
.text
    # Area de instrucoes na memoria
    # li - load immediate (pseudoinstrucao)
    li $v0, 4 # Codigo para imprimir string 
    # la - load address (pseudoinstrucao)
    la $a0, my_str # Carrega o endereco da variavel (ponteiro) em $a0 
    syscall # Executa a chamada de sistema indicado pelo valor em $v0
	
