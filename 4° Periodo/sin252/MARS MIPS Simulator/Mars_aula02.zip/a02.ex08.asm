# SIN 252 - Arquietura de Computadores (2024)
# Prof. Joao Fernando Mari
# joaofmari.github.io
# ==================================================
# a02.ex08.asm
# ==================================================
# include <stdio.h>
# 
# int fact (int n){
#    if (n < 1)
#        return(1);
#    else 
#        return (n * fact(n-1));
# }
# 
# int main() {
#    int a, b; // $s0 e $s1
#    a = func1(2, 3);
#    printf("%d", a);
#    return 0;
# }
# --------------------------------------------------

.data

.text
    main:
        addi $a0, $a0, 3
        jal  fact
        add $s0, $zero, $v0
        # Print
        li $v0, 1
        move $a0, $s0 # pseudo-instrucao
        syscall
        # Encerra o programa
        li $v0, 10 # pseudo-instrucao
        syscall 
    fact: 
        addi $sp, $sp, -8	# ajusta pilha para 2 itens
        sw $ra, 4($sp)	            # salva endereco de retorno
        sw $a0, 0($sp)	            # salva o argumento n
        slti $t0, $a0, 1	# se (n<1): $t0=1; se n>=1: $t1=0
        beq $t0, $zero, ELSE	# se n >= 1, desvia para ELSE
        addi $v0, $zero, 1 	# prepara o valor de retorno de fact
        addi $sp, $sp, 8	# retira dois itens da pilha
        jr $ra		# retorna
    ELSE: 
        addi $a0,$a0, -1	# argumento recebe n-1
        jal fact		# chama fact com n-1
        lw $a0, 0($sp)	            # retorna de jal: restaura o arg. n
        lw $ra, 4($sp)	            # restaura o endereço de retorno
        addi $sp, $sp, 8	# ajusta pilha para remover 2 itens
        mul $v0, $a0, $v0	# calcula n * fact(n-1)
        jr $ra		# retorna para o procedimento que chamou

           
           
           
                   
    
                    
                   

