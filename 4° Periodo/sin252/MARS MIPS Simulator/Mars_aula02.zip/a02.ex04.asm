# SIN 252 - Arquietura de Computadores (2024)
# Prof. Joao Fernando Mari
# joaofmari.github.io
# ==================================================
# a02.ex04.asm
# ==================================================
# int a, b, f, g, h;  // $s0, $s1, $s2, $s3, $s4
# a = 10; b = 10; g = 3; h = 2;
# 
# if(a < b) {
#     f = g + h;
# } else {
#     f = g - h;
# }
# prinft("%d", f)
#
# if(a > b) {
#     f = g + h;
# } else {
#     f = g - h;
# }
# prinft("%d", f)
#
# if(a <= b) {
#     f = g + h;
# } else {
#     f = g - h;
# }
# prinft("%d", f)
#
# if(a >= b) {
#     f = g + h;
# } else {
#     f = g - h;
# }
# prinft("%d", f)
#
# --------------------------------------------------

.data
    a: .word 10 # $s0
    b: .word 10 # $s1
    f: .word 0  # $s2
    g: .word 3  # $s3
    h: .word 2  # $s4

.text
           la $t0, a # endereco de i em $t0 (pseudo-instrucao)
           lw $s0, 0($t0) # valor de i em $s3
           la $t0, b # endereco de j em $t0 (pseudo-instrucao)
           lw $s1, 0($t0) # valor de j em $s4
           
           la $t0, g # endereco de g em $t0 (pseudo-instrucao)
           lw $s3, 0($t0) # valor de g em $s1
           la $t0, h # endereco de h em $t0 (pseudo-instrucao)
           lw $s4, 0($t0) # valor de h em $s2   

           # if ($s3 < $s4) ...
           slt $t0, $s0, $s1    # $t0=1 se $s0<$s1 (a<b)
           beq $t0, $zero, else1 # desvia se $t0 == 0
           add $s2, $s3, $s4    # f = g + h
           j exit1               # go to exit
    else1: sub $s2, $s3, $s4    # f = g - h
    exit1: la $t0, f
           sw $s2, 0($t0)
           # Print
           li $v0, 1
           move $a0, $s2 # pseudo-instrucao
           syscall
          
           # if ($s3 > $s4) ...
           slt $t0, $s1, $s0    # $t0=1 se $s1<$s0 ((b<a) == (a>b))
           beq $t0, $zero, else2 # desvia se $t0 == 0
           add $s2, $s3, $s4
           j exit2             # go to exit
    else2: sub $s2, $s3, $s4
    exit2: la $t0, f
           sw $s2, 0($t0)
           # Print
           li $v0, 1
           move $a0, $s2 # pseudo-instrucao
           syscall
    
           # if ($s3 >= $s4) ...
           slt $t0, $s0, $s1    # $t0=1 se $s0<$s1 ((a>=b) == !(a<b))
           bne $t0, $zero, else3 # desvia se $t0 != 0
           add $s2, $s3, $s4
           j exit3               # go to exit
    else3: sub $s2, $s3, $s4
    exit3: la $t0, f
           sw $s2, 0($t0)
           # Print
           li $v0, 1
           move $a0, $s2 # pseudo-instrucao
           syscall
          
           # if ($s3 <= $s4) ...
           slt $t0, $s0, $s1    # $t0=1 se $s1<$s0 ((a<=b) == !(a>b))
           bne $t0, $zero, else4 # desvia se $t0 != 0
           add $s2, $s3, $s4
           j exit4             # go to exit
    else4: sub $s2, $s3, $s4
    exit4: la $t0, f
            sw $s2, 0($t0)
           # Print
           li $v0, 1
           move $a0, $s2 # pseudo-instrucao
           syscall
    
          # Encerra o programa
          li $v0, 10 # pseudo-instrucao
          syscall    
