# SIN 252 - Arquietura de Computadores (2024)
# Prof. Joao Fernando Mari
# joaofmari.github.io
# ==================================================
# a02.ex02.asm
# ==================================================
# int A = {10, 11, 12, 13, 14, 15, 16, 17, 10, 19};  // $s3
# int h = 6;  // $s2
#
# A[4] = h + A[8];
# --------------------------------------------------

.data
    A: .word 10, 11, 12, 13, 14, 15, 16, 17, 18, 19 # $s3
    h: .word 6 # $s2

.text
    la $s3, A # pseudo-instrucao
    la $t0, h
    lw $s2, 0($t0) # h
    lw $t0, 32($s3) # A[8]
    add $t0, $s2, $t0  # $t0 = h + A[8]
    sw $t0, 16($s3) 
    # Print
    li $v0, 1
    move $a0, $t0 # pseudo-instrucao
    syscall
    # Encerra o programa
    li $v0, 10 # pseudo-instrucao
    syscall    
