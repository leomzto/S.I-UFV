# SIN 252 - Arquietura de Computadores (2024)
# Prof. Joao Fernando Mari
# joaofmari.github.io
# ==================================================
# a02.ex01.asm
# ==================================================
# int f, g, h, i, j;   # $s0-$s4
# g = 9; h = 2; i = 5,; j = 3
# 
# f = (g + h) - (i + j);
# --------------------------------------------------

.data
    g: .word 9
    h: .word 2
    i: .word 5
    j: .word 3
    f: .word 0      

.text
    la $t0, g # pseudo-instrucao
    lw $s1, 0($t0)
    la $t0, h
    lw $s2, 0($t0)
    la $t0, i
    lw $s3, 0($t0)
    la $t0, j
    lw $s4, 0($t0)
    
    add $t0, $s1, $s2
    add $t1, $s3, $s4
    sub $s0, $t0, $t1
    
    la $t0, f
    sw $s0, 0($t0)
    # Print
    li $v0, 1
    move $a0, $s0 # pseudo-instrucao
    syscall
    
    li $v0, 10 # pseudo-instrucao
    syscall    

