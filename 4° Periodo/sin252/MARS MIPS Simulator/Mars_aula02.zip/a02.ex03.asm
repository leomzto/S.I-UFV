# SIN 252 - Arquietura de Computadores (2024)
# Prof. Joao Fernando Mari
# joaofmari.github.io
# ==================================================
# a02.ex03.asm
# ==================================================
# int i, j, f, g, h;   // $s3, $s4, $s0, $s1, $s2
# i = 10; j = 10; g = 2; h = 3;
# 
# if (i == j)
#     f = g + h; 
# else
#     f = g - h;
# --------------------------------------------------

.data
    i: .word 10 # $s3
    j: .word 10 # $s4
    f: .word 0  # $s0
    g: .word 2  # $S1
    h: .word 3  # $s2

.text
          la $t0, i # endereco de i em $t0 (pseudo-instrucao)
          lw $s3, 0($t0) # valor de i em $s3
          la $t0, j # endereco de j em $t0 (pseudo-instrucao)
          lw $s4, 0($t0) # valor de j em $s4
          
          la $t0, g # endereco de g em $t0 (pseudo-instrucao)
          lw $s1, 0($t0) # valor de g em $s1
          la $t0, h # endereco de h em $t0 (pseudo-instrucao)
          lw $s2, 0($t0) # valor de h em $s2

          # if ($s3 == $s4) ...
          bne $s3, $s4, else # se #s3 != $4 goto else
          add $s0, $s1, $s2
          j exit             # go to exit
    else: sub $s0, $s1, $s2
    exit: la $t0, f
          sw $s0, 0($t0)
    
          # Print
          li $v0, 1
          move $a0, $s0 # pseudo-instrucao
          syscall
    
          # Encerra o programa
          li $v0, 10 # pseudo-instrucao
          syscall    
