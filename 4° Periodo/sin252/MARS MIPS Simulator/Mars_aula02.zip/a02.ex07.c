// SIN252 Arquitetura de Computadores (2024)
// Prof. Joao Fernando Mari
// joaofmari.github.io
// ==================================================
// a02.ex07.asm
// ==================================================
#include <stdio.h>

int func2(int m) { // $a0
   int a; // $s0
   if (m >= 0) 
      a = m - 1;
   else
      a = m + 1;
   return a;
}

int func1(int m, int n){ // $a0 e $a1
    int c, d; // $s0 e  $s1
    c = m + n;
    d = func2(c);
    return d;
}

int main() {
   int a, b; // $s0 e $s1
   a = func1(2, 3);
   printf("%d", a);
   b = func2(a);
   printf("\n%d", b);
   return 0;
}












// --------------------------------------------------
