# a02.ex06.asm
# ==================================================
# void main() {
#    int a;
#    a = exemplo_folha(2, 3, 5, 6);
#    printf("%d", a)
# }
# 
# int exemplo_folha (int g, int h, int i, int j){ // $a0 - $a3
#     int f; // $s0
#     f = ( g + h ) – ( i + j );
#     return f;
# }
# --------------------------------------------------

.data

.text
    main:	       addi $a0, $zero, 2
                   addi $a1, $zero, 3
                   addi $a2, $zero, 5
                   addi $a3, $zero, 6
               
                   # 
                   jal exemplo_folha
                   add $s0, $zero, $v0
               
                   # Print
                   li $v0, 1
                   move $a0, $s0 # pseudo-instrução
                   syscall
    
                   # Encerra o programa
                   li $v0, 10 # pseudo-instrução
                   syscall    
                   
    exemplo_folha: addi $sp, $sp, -4     # ajusta a pilha (1 itens)
                   sw   $s0, 0($sp)          # empilha registrador $s0
                   add  $t0, $a0, $a1    # $t0 contém g+h
                   add  $t1, $a2, $a3    # $t1 contém i+j
                   sub  $s0, $t0, $t1    # f = (g+h) – (i+j)
                   add  $v0, $s0, $zero  # copia f para reg. de retorno
                   lw   $s0, 0($sp)      # desempilha registrador $s0
                   addi $sp, $sp, 4      # exclui 1 itens da pilha
                   jr   $ra              # Retorna para o endereço em $ra
	   	   



