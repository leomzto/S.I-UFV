# SIN 252 - Arquietura de Computadores (2024)
# Prof. Joao Fernando Mari
# joaofmari.github.io
# ==================================================
# a02.ex07a.asm
# Versao mais complexa de ex07
# ==================================================
# include <stdio.h>
# 
# int func2(int m) { // $a0
#    int a; // $s0
#    if (m >= 0) 
#       a = m - 1;
#    else
#       a = m + 1;
#    return a;
# }
# 
# int func1(int m, int n){ // $a0 e $a1
#     int c, d; // $s0 e  $s1
#     c = m + n;
#     d = func2(c);
#     return d;
# }
# 
# int main() {
#    int a, b; // $s0 e $s1
#    a = func1(2, 3);
#    printf("%d", a);
#    b = func2(a);
#    printf("\n%d", b);
#    return 0;
# }
# --------------------------------------------------

.data

.text
    main:   # Alimenta registradores de argumentos para a chamada de func1
    	    addi $a0, $zero, 2
            addi $a1, $zero, 3
            jal  func1
            add  $s0, $zero, $v0
            # Print
            li   $v0, 1
            move $a0, $s0 # pseudo-instrucao
            syscall
            # Alimenta registradores de argumentos para a chamada de func2
            add  $a0, $zero, $s0
            jal  func2
            add  $s1, $zero, $v0
            # Print
            li   $v0, 1
            move $a0, $s1 # pseudo-instrucao
            syscall
            # Encerra o programa
            li  $v0, 10 # pseudo-instrucao
            syscall   
          
    func1: # Funcao chamada empilha $ra (somente se nao-folha) e $sX.
           addi $sp, $sp, -12  # ajusta a pilha (3 itens)
           sw   $ra, 8($sp) # $ra - funcao chamada empilha
           sw   $s0, 4($sp) # c - funcao chamada empilha
           sw   $s1, 0($sp) # d - funcao chamada empilha
           # Codigo da funcao
           # Funcao chamadora (portanto nao-folha) empilha $aX e $tX, 
           # Somente se necessario.
           addi $sp, $sp, -8  # Nao e necessario aqui, pois nao vamos utilizar $a0 e $a1 apos a chamada de func2
           sw   $a0, 4($sp)   # Fizemos apenas para demonstracao.
           sw   $a1, 0($sp)
           # Alimenta registradores e argumentos
           add  $a0, $zero, $s0
           jal  func2
           add  $s1, $zero, $v0
           # Desempilha $sX e $tX, caso tenha empilhado
           lw   $a1, 0($sp)
           lw   $a0, 4($sp)
           addi $sp, $sp, 8 # Libera espaco na pilha
           add  $v0, $zero, $s1
           # Desempilha 
           lw   $s1, 0($sp)
           lw   $s0, 4($sp)
           lw   $ra, 8($sp)
           addi $sp, $sp, 12 # Libera espaco na pilha
           # Retorna o controle para a funcao chamadora
           jr   $ra
           
    func2: addi $sp, $sp, -4     # ajusta a pilha (3 itens)
           sw   $s0, 0($sp) 
           slti $t0, $a0, 0  
           bne  $t0, $zero, else
           addi $s0, $a0, -1
           j    exit
    else:  addi $s0, $a0, 1
    exit:  add  $v0, $zero, $s0
           lw   $s0, 0($sp)
           add  $sp, $sp, 4
           jr   $ra
           
           
           
                   
    
                    
                   

