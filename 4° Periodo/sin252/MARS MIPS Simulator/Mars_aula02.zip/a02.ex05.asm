# SIN 252 - Arquietura de Computadores (2024)
# Prof. Joao Fernando Mari
# joaofmari.github.io
# ==================================================
# a02.ex05.asm
# ==================================================
# int A = {10, 10, 10, 10, 14, 15, 16, 17, 10, 19};
# int i = 0;
# int k = 10;
#
# while (save[i] == k)
#     i += 1;
# --------------------------------------------------

.data
    # A = {10, 10, 10, 10, 14, 15, 16, 17, 10, 19}; $s6
    save: .word 10, 10, 10, 10, 14, 15, 16, 17, 10, 19 
    i: .word 0 # i = 0; $s3
    k: .word 10  # k = 10; $s5     

.text
          la $s6, save # pseudo-instrucao
          la $t0, i
          lw $s3, 0($t0)
          la $t1, k
          lw $s5, 0($t1)
    loop: sll $t1, $s3, 2
          add $t1, $t1, $s6
          lw $t2, 0($t1)
          bne $t2, $s5, exit
          addi $s3, $s3, 1
          j loop
    exit: sw $s3, 0($t0) 
          # Print
          li $v0, 1
          move $a0, $s3 # pseudo-instrucao
          syscall
          # Encerra o programa
          li $v0, 10 # pseudo-instrucao
          syscall    
